`timescale 1ns/1ps

// ============================================================
// MODIFIED AdAM
//
// N = 8
// T = 2
// H = 3
//
// MODIFICATION 1:
// Carry-safe operand isolation in redundant protection path.
//
// MODIFICATION 2:
// Early-zero operand isolation.
//
// IMPORTANT:
// H is FIXED.
// WPB is DYNAMIC.
// ============================================================


// ============================================================
// LEADING ONE DETECTOR
// ============================================================

module madam_lod #(
    parameter N = 8
)(
    input  wire [N-1:0] x,
    output reg [$clog2(N)-1:0] k,
    output reg zero
);

    integer i;
    reg found;

    always @(*) begin

        k = 0;
        found = 1'b0;

        for (i=N-1; i>=0; i=i-1) begin

            if ((!found) && x[i]) begin
                k = i;
                found = 1'b1;
            end

        end

        zero = ~found;

    end

endmodule


// ============================================================
// PARTIAL FULL ADDER
// ============================================================

module madam_pfa(
    input  wire a,
    input  wire b,
    input  wire cin,

    output wire sum,
    output wire cout
);

    assign sum =
        a ^ b ^ cin;

    assign cout =
        (a & b) |
        (a & cin) |
        (b & cin);

endmodule


// ============================================================
// CLA
// ============================================================

module madam_cla #(
    parameter WIDTH = 4
)(
    input  wire [WIDTH-1:0] a,
    input  wire [WIDTH-1:0] b,
    input  wire cin,

    output wire [WIDTH-1:0] sum,
    output wire [WIDTH:0] carry
);

    wire [WIDTH-1:0] p;
    wire [WIDTH-1:0] g;

    assign p = a ^ b;
    assign g = a & b;

    assign carry[0] = cin;

    genvar i;

    generate

        for (i=0; i<WIDTH; i=i+1)
        begin : GEN_MOD_CLA_BITS

            assign carry[i+1] =
                g[i] |
                (p[i] & carry[i]);

            assign sum[i] =
                p[i] ^ carry[i];

        end

    endgenerate

endmodule


// ============================================================
// HYBRID ADDER
//
// Lower half  -> ripple PFA
// Upper half  -> CLA
// ============================================================

module madam_hybrid #(
    parameter WIDTH = 4
)(
    input wire [WIDTH-1:0] a,
    input wire [WIDTH-1:0] b,

    output wire [WIDTH-1:0] sum
);

    localparam LOWER_WIDTH = WIDTH/2;
    localparam UPPER_WIDTH = WIDTH-LOWER_WIDTH;

    wire [LOWER_WIDTH:0] lower_carry;

    wire [UPPER_WIDTH-1:0] upper_sum;
    wire [UPPER_WIDTH:0] upper_carry;

    assign lower_carry[0] = 1'b0;

    genvar i;

    generate

        for (i=0; i<LOWER_WIDTH; i=i+1)
        begin : GEN_MOD_RIPPLE

            madam_pfa FA (

                .a(
                    a[i]
                ),

                .b(
                    b[i]
                ),

                .cin(
                    lower_carry[i]
                ),

                .sum(
                    sum[i]
                ),

                .cout(
                    lower_carry[i+1]
                )

            );

        end

    endgenerate


    madam_cla #(
        .WIDTH(UPPER_WIDTH)
    ) UPPER_CLA (

        .a(
            a[WIDTH-1:LOWER_WIDTH]
        ),

        .b(
            b[WIDTH-1:LOWER_WIDTH]
        ),

        .cin(
            lower_carry[LOWER_WIDTH]
        ),

        .sum(
            upper_sum
        ),

        .carry(
            upper_carry
        )

    );


    assign sum[WIDTH-1:LOWER_WIDTH] =
        upper_sum;

endmodule


// ============================================================
// MAJORITY VOTER
// ============================================================

module madam_majority(
    input wire a,
    input wire b,
    input wire c,

    output wire y
);

    assign y =
        (a & b) |
        (a & c) |
        (b & c);

endmodule


// ============================================================
// 3-WAY TMR CHARACTERISTIC ADDER
//
// THIS IS KEPT UNCHANGED.
// ============================================================

module madam_tmr #(
    parameter WIDTH = 4
)(
    input wire [WIDTH-1:0] a,
    input wire [WIDTH-1:0] b,

    output wire [WIDTH-1:0] sum
);

    wire [WIDTH-1:0] result1;
    wire [WIDTH-1:0] result2;
    wire [WIDTH-1:0] result3;


    madam_hybrid #(
        .WIDTH(WIDTH)
    ) ADDER1 (

        .a(a),
        .b(b),

        .sum(result1)

    );


    madam_hybrid #(
        .WIDTH(WIDTH)
    ) ADDER2 (

        .a(a),
        .b(b),

        .sum(result2)

    );


    madam_hybrid #(
        .WIDTH(WIDTH)
    ) ADDER3 (

        .a(a),
        .b(b),

        .sum(result3)

    );


    genvar i;

    generate

        for (i=0; i<WIDTH; i=i+1)
        begin : GEN_MOD_TMR

            madam_majority VOTER (

                .a(result1[i]),
                .b(result2[i]),
                .c(result3[i]),

                .y(sum[i])

            );

        end

    endgenerate

endmodule


// ============================================================
// CARRY-SAFE MODIFIED ADAPTIVE ADDER
//
// KEY IDEA:
//
// H = maximum available redundant protection bits.
//
// WPB = actual number of protected bits.
//
// Instead of disabling a lower redundant PFA and accidentally
// removing the carry needed by an upper protected bit, the
// redundant path begins at the FIRST ACTUALLY PROTECTED BIT.
//
// The carry entering that protected region is taken from the
// primary adder.
//
// Therefore:
//
//     protected redundant computation
//                 |
//                 v
//        independently recomputed
//        protected upper bits
//
// while unnecessary lower redundant PFAs are isolated.
// ============================================================

module madam_adaptive #(
    parameter N = 8,
    parameter T = 2,
    parameter H = 3
)(
    input wire [N-2:0] a,
    input wire [N-2:0] b,

    input wire [$clog2(N)-1:0] k,

    output wire [N-2:0] sum,

    output wire carry_out,

    output wire fault_detected,

    output reg [H-1:0] duplicate_enable,

    output reg [H-1:0] isolated_a,

    output reg [H-1:0] isolated_b
);

    localparam M =
        N-1;

    localparam KW =
        $clog2(N);


    // ========================================================
    // ADAPTIVE PARAMETERS
    // ========================================================

    wire [KW:0] wx;
    wire [KW:0] war;
    wire [KW:0] wpb;


    // --------------------------------------------------------
    // W_Xt
    // --------------------------------------------------------

    assign wx =
        (k < (N-T))
        ?
        k
        :
        (M-T);


    // --------------------------------------------------------
    // W_AR
    // --------------------------------------------------------

    assign war =
        M-wx;


    // --------------------------------------------------------
    // W_PB
    //
    // H remains fixed.
    // WPB is the actual protection width.
    // --------------------------------------------------------

    assign wpb =
        (war < H)
        ?
        war
        :
        H;


    // ========================================================
    // PRIMARY ADAPTIVE ADDER
    // ========================================================

    wire [M-1:0] primary_sum;

    wire [M:0] primary_carry;


    madam_cla #(
        .WIDTH(M)
    ) PRIMARY_ADDER (

        .a(
            a
        ),

        .b(
            b
        ),

        .cin(
            1'b0
        ),

        .sum(
            primary_sum
        ),

        .carry(
            primary_carry
        )

    );


    // ========================================================
    // REDUNDANT REGION
    //
    // Physical H-bit region:
    //
    // global bits:
    //
    // M-H ........ M-1
    //
    // For N=8:
    //
    // M = 7
    // H = 3
    //
    // redundant region = bits 4,5,6
    // ========================================================

    wire [H-1:0] raw_a;
    wire [H-1:0] raw_b;


    assign raw_a =
        a[M-1 -: H];

    assign raw_b =
        b[M-1 -: H];


    // ========================================================
    // CARRY-SAFE OPERAND ISOLATION
    // ========================================================

    reg [H-1:0] duplicate_sum;

    reg [H:0] duplicate_carry;

    integer d;

    integer wpb_int;

    integer start_bit;

    integer global_bit;


    always @(*) begin

        // ----------------------------------------------------
        // Defaults
        // ----------------------------------------------------

        duplicate_enable =
            {H{1'b0}};

        isolated_a =
            {H{1'b0}};

        isolated_b =
            {H{1'b0}};

        duplicate_sum =
            {H{1'b0}};

        duplicate_carry =
            {(H+1){1'b0}};


        // ----------------------------------------------------
        // Convert WPB to integer
        // ----------------------------------------------------

        wpb_int =
            wpb;


        // ----------------------------------------------------
        // First protected global bit
        //
        // Example:
        //
        // M=7, WPB=2
        //
        // start_bit = 7-2 = 5
        //
        // Therefore only bits 5 and 6 are redundantly
        // recomputed.
        // ----------------------------------------------------

        start_bit =
            M-wpb_int;


        if (start_bit < 0)
            start_bit = 0;


        // ----------------------------------------------------
        // IMPORTANT:
        //
        // Carry entering first protected bit comes from
        // the primary computation.
        //
        // This prevents isolation of an unused lower
        // redundant PFA from changing the protected result.
        // ----------------------------------------------------

        duplicate_carry[0] =
            primary_carry[start_bit];


        // ----------------------------------------------------
        // Process H redundant positions.
        // ----------------------------------------------------

        for (d=0; d<H; d=d+1) begin

            global_bit =
                (M-H)+d;


            // ------------------------------------------------
            // Is this bit actually protected?
            // ------------------------------------------------

            if (global_bit >= start_bit) begin

                // --------------------------------------------
                // ACTIVE REDUNDANT RESOURCE
                // --------------------------------------------

                duplicate_enable[d] =
                    1'b1;


                // --------------------------------------------
                // Original operands are connected.
                // --------------------------------------------

                isolated_a[d] =
                    raw_a[d];

                isolated_b[d] =
                    raw_b[d];


                // --------------------------------------------
                // Redundant PFA computation.
                // --------------------------------------------

                duplicate_sum[d] =
                    isolated_a[d] ^
                    isolated_b[d] ^
                    duplicate_carry[d];


                duplicate_carry[d+1] =
                    (
                        isolated_a[d] &
                        isolated_b[d]
                    )
                    |
                    (
                        isolated_a[d] &
                        duplicate_carry[d]
                    )
                    |
                    (
                        isolated_b[d] &
                        duplicate_carry[d]
                    );

            end
            else begin

                // --------------------------------------------
                // INACTIVE REDUNDANT RESOURCE
                //
                // Operand isolation:
                //
                // a = 0
                // b = 0
                //
                // No arithmetic is performed for this
                // unnecessary redundant position.
                // --------------------------------------------

                duplicate_enable[d] =
                    1'b0;


                isolated_a[d] =
                    1'b0;

                isolated_b[d] =
                    1'b0;


                duplicate_sum[d] =
                    1'b0;


                // --------------------------------------------
                // Carry is simply passed through.
                //
                // This position is NOT allowed to corrupt
                // the carry entering an active protected bit.
                // --------------------------------------------

                duplicate_carry[d+1] =
                    duplicate_carry[d];

            end

        end

    end


    // ========================================================
    // BUILD FULL DUPLICATE RESULT
    // ========================================================

    reg [M-1:0] duplicate_full;

    reg [M-1:0] protected_mask;


    integer mbit;

    integer duplicate_index;

    integer first_protected;


    always @(*) begin

        duplicate_full =
            {M{1'b0}};

        protected_mask =
            {M{1'b0}};


        wpb_int =
            wpb;


        first_protected =
            M-wpb_int;


        if (first_protected < 0)
            first_protected = 0;


        for (mbit=0; mbit<M; mbit=mbit+1) begin

            if (mbit >= first_protected) begin

                protected_mask[mbit] =
                    1'b1;


                duplicate_index =
                    mbit-(M-H);


                if (
                    (duplicate_index >= 0) &&
                    (duplicate_index < H)
                ) begin

                    duplicate_full[mbit] =
                        duplicate_sum[
                            duplicate_index
                        ];

                end
                else begin

                    duplicate_full[mbit] =
                        1'b0;

                end

            end
            else begin

                protected_mask[mbit] =
                    1'b0;

                duplicate_full[mbit] =
                    1'b0;

            end

        end

    end


    // ========================================================
    // FAULT DETECTION
    // ========================================================

    assign fault_detected =
        |(
            (primary_sum ^
             duplicate_full)
            &
            protected_mask
        );


    // ========================================================
    // FAULT MASKING
    //
    // IMPORTANT:
    //
    // If redundant result agrees:
    //     primary result retained.
    //
    // If mismatch:
    //     affected protected bit is masked.
    //
    // This preserves the existing AdAM mitigation concept.
    // ========================================================

    assign sum =
        (
            primary_sum &
            ~protected_mask
        )
        |
        (
            primary_sum &
            duplicate_full &
            protected_mask
        );


    assign carry_out =
        primary_carry[M];

endmodule


// ============================================================
// RECONSTRUCTION
// ============================================================

module madam_reconstruct #(
    parameter N = 8
)(
    input wire [$clog2(N):0] exponent,

    input wire [N-2:0] fraction,

    input wire fraction_carry,

    output reg [2*N-1:0] product
);

    localparam M =
        N-1;


    // M+2 bits are required.
    reg [M+1:0] significand;

    reg [2*N-1:0] temp;

    integer exp_int;

    integer shift_amount;


    always @(*) begin

        // ----------------------------------------------------
        // Construct 1 + XA + XB
        // ----------------------------------------------------

        if (fraction_carry) begin

            // 10.xxxxx
            significand =
                {
                    2'b10,
                    fraction
                };

        end
        else begin

            // 01.xxxxx
            significand =
                {
                    2'b01,
                    fraction
                };

        end


        exp_int =
            exponent;


        temp =
            {2*N{1'b0}};


        // ----------------------------------------------------
        // Fixed-point reconstruction
        // ----------------------------------------------------

        if (exp_int >= M) begin

            shift_amount =
                exp_int-M;


            temp =
                significand
                << shift_amount;

        end
        else begin

            shift_amount =
                M-exp_int;


            temp =
                significand
                >> shift_amount;

        end


        product =
            temp;

    end

endmodule


// ============================================================
// MODIFIED AdAM TOP
// ============================================================

module adam_modified #(
    parameter N = 8,
    parameter T = 2,
    parameter H = 3
)(
    input wire [N-1:0] A,
    input wire [N-1:0] B,

    output wire [2*N-1:0] P,

    output wire zero_debug,

    output wire [$clog2(N)-1:0] kA_debug,

    output wire [$clog2(N)-1:0] kB_debug,

    output wire [N-2:0] mantA_debug,

    output wire [N-2:0] mantB_debug,

    output wire [N-2:0] mant_sum_debug,

    output wire mant_carry_debug,

    output wire [H-1:0] duplicate_enable_debug,

    output wire [H-1:0] isolated_a_debug,

    output wire [H-1:0] isolated_b_debug,

    output wire fault_debug
);

    localparam M =
        N-1;

    localparam KW =
        $clog2(N);


    // ========================================================
    // LOD
    // ========================================================

    wire [KW-1:0] kA;
    wire [KW-1:0] kB;

    wire zeroA;
    wire zeroB;


    madam_lod #(
        .N(N)
    ) LOD_A (

        .x(A),

        .k(kA),

        .zero(zeroA)

    );


    madam_lod #(
        .N(N)
    ) LOD_B (

        .x(B),

        .k(kB),

        .zero(zeroB)

    );


    // ========================================================
    // ZERO FLAG
    // ========================================================

    wire zero_flag;


    assign zero_flag =
        zeroA | zeroB;


    // ========================================================
    // NORMALIZATION
    // ========================================================

    wire [KW-1:0] shiftA;
    wire [KW-1:0] shiftB;


    assign shiftA =
        M-kA;


    assign shiftB =
        M-kB;


    wire [N-1:0] normA;
    wire [N-1:0] normB;


    assign normA =
        A << shiftA;


    assign normB =
        B << shiftB;


    wire [M-1:0] mantA_raw;
    wire [M-1:0] mantB_raw;


    assign mantA_raw =
        normA[M-1:0];


    assign mantB_raw =
        normB[M-1:0];


    // ========================================================
    // ADAPTIVE TRUNCATION
    // ========================================================

    reg [M-1:0] mantA;
    reg [M-1:0] mantB;


    integer keepA;
    integer keepB;

    integer discardA;
    integer discardB;

    integer ti;


    always @(*) begin

        // ----------------------------------------------------
        // A
        // ----------------------------------------------------

        if (kA < (N-T))
            keepA = kA;
        else
            keepA = M-T;


        discardA =
            M-keepA;


        mantA =
            {M{1'b0}};


        for (
            ti=0;
            ti<M;
            ti=ti+1
        ) begin

            if (ti >= discardA)
                mantA[ti] =
                    mantA_raw[ti];

        end


        // ----------------------------------------------------
        // B
        // ----------------------------------------------------

        if (kB < (N-T))
            keepB = kB;
        else
            keepB = M-T;


        discardB =
            M-keepB;


        mantB =
            {M{1'b0}};


        for (
            ti=0;
            ti<M;
            ti=ti+1
        ) begin

            if (ti >= discardB)
                mantB[ti] =
                    mantB_raw[ti];

        end

    end


    // ========================================================
    // MODIFICATION 2:
    // EARLY ZERO ISOLATION
    //
    // The zero flag generated by LOD is reused BEFORE the
    // adaptive arithmetic.
    // ========================================================

    wire early_enable;


    assign early_enable =
        ~zero_flag;


    wire [M-1:0] mantA_isolated;
    wire [M-1:0] mantB_isolated;


    assign mantA_isolated =
        mantA &
        {M{early_enable}};


    assign mantB_isolated =
        mantB &
        {M{early_enable}};


    // ========================================================
    // MAXIMUM CHARACTERISTIC
    // ========================================================

    wire [KW-1:0] kmax;


    assign kmax =
        (kA > kB)
        ?
        kA
        :
        kB;


    // ========================================================
    // MODIFIED ADAPTIVE ADDER
    // ========================================================

    wire [M-1:0] mant_sum;

    wire mant_carry;

    wire fault_detected;


    madam_adaptive #(
        .N(N),
        .T(T),
        .H(H)
    ) ADAPTIVE (

        .a(
            mantA_isolated
        ),

        .b(
            mantB_isolated
        ),

        .k(
            kmax
        ),

        .sum(
            mant_sum
        ),

        .carry_out(
            mant_carry
        ),

        .fault_detected(
            fault_detected
        ),

        .duplicate_enable(
            duplicate_enable_debug
        ),

        .isolated_a(
            isolated_a_debug
        ),

        .isolated_b(
            isolated_b_debug
        )

    );


    // ========================================================
    // TMR CHARACTERISTIC ADDER
    // ========================================================

    wire [KW:0] ksum;


    madam_tmr #(
        .WIDTH(KW+1)
    ) TMR (

        .a(
            {1'b0,kA}
        ),

        .b(
            {1'b0,kB}
        ),

        .sum(
            ksum
        )

    );


    // ========================================================
    // EARLY ZERO ISOLATION BEFORE RECONSTRUCTION
    // ========================================================

    wire [KW:0] ksum_isolated;

    wire [M-1:0] mant_sum_isolated;

    wire mant_carry_isolated;


    assign ksum_isolated =
        ksum &
        {(KW+1){early_enable}};


    assign mant_sum_isolated =
        mant_sum &
        {M{early_enable}};


    assign mant_carry_isolated =
        mant_carry &
        early_enable;


    // ========================================================
    // RECONSTRUCTION
    // ========================================================

    wire [2*N-1:0] reconstructed;


    madam_reconstruct #(
        .N(N)
    ) RECONSTRUCT (

        .exponent(
            ksum_isolated
        ),

        .fraction(
            mant_sum_isolated
        ),

        .fraction_carry(
            mant_carry_isolated
        ),

        .product(
            reconstructed
        )

    );


    // ========================================================
    // FINAL ZERO SELECTION
    // ========================================================

    assign P =
        zero_flag
        ?
        {2*N{1'b0}}
        :
        reconstructed;


    // ========================================================
    // DEBUG OUTPUTS
    // ========================================================

    assign zero_debug =
        zero_flag;


    assign kA_debug =
        kA;


    assign kB_debug =
        kB;


    assign mantA_debug =
        mantA_isolated;


    assign mantB_debug =
        mantB_isolated;


    assign mant_sum_debug =
        mant_sum;


    assign mant_carry_debug =
        mant_carry;


    assign fault_debug =
        fault_detected;

endmodule