`timescale 1ns / 1ps

module mitchell_multiplier #(
    parameter N = 8
)(
    input  wire [N-1:0] A,
    input  wire [N-1:0] B,
    output reg  [(2*N)-1:0] P
);

    integer i;

    // -----------------------------------------
    // Log-domain quantities
    // -----------------------------------------

    reg [N-1:0] kA;
    reg [N-1:0] kB;

    reg found_A;
    reg found_B;

    // Normalized operands
    reg [N-1:0] norm_A;
    reg [N-1:0] norm_B;

    // Fractional parts
    reg [N-2:0] frac_A;
    reg [N-2:0] frac_B;

    // Fractional addition
    // N bits because XA + XB can overflow
    reg [N-1:0] frac_sum;

    // Reconstructed mantissa
    // Scaled by 2^(N-1)
    reg [N-1:0] mantissa;

    integer exponent_sum;
    integer shift_amount;

    reg [(2*N)-1:0] temp_result;


    // =========================================
    // Mitchell multiplier
    // =========================================

    always @(*) begin

        // -------------------------------------
        // Default values
        // -------------------------------------

        kA = 0;
        kB = 0;

        found_A = 1'b0;
        found_B = 1'b0;

        norm_A = 0;
        norm_B = 0;

        frac_A = 0;
        frac_B = 0;

        frac_sum = 0;

        mantissa = 0;

        exponent_sum = 0;
        shift_amount = 0;

        temp_result = 0;

        P = 0;


        // =====================================
        // LOG: Leading-one detection
        // =====================================

        for (i = N-1; i >= 0; i = i-1) begin

            if ((A[i] == 1'b1) && (found_A == 1'b0)) begin
                kA = i;
                found_A = 1'b1;
            end

            if ((B[i] == 1'b1) && (found_B == 1'b0)) begin
                kB = i;
                found_B = 1'b1;
            end

        end


        // =====================================
        // Zero handling
        // =====================================

        if ((A == 0) || (B == 0)) begin

            P = 0;

        end
        else begin

            // =================================
            // Normalize A
            //
            // A = 2^kA (1 + XA)
            // =================================

            norm_A = A << (N-1-kA);

            // Remove leading 1
            frac_A = norm_A[N-2:0];


            // =================================
            // Normalize B
            //
            // B = 2^kB (1 + XB)
            // =================================

            norm_B = B << (N-1-kB);

            // Remove leading 1
            frac_B = norm_B[N-2:0];


            // =================================
            // MITCHELL LOG APPROXIMATION
            //
            // (1+XA)(1+XB)
            //
            // ≈
            //
            // 1 + XA + XB
            //
            // XA*XB is discarded
            // =================================

            frac_sum =
                {1'b0, frac_A} +
                {1'b0, frac_B};


            // =================================
            // Characteristic addition
            // =================================

            exponent_sum = kA + kB;


            // =================================
            // ANTILOG / RECONSTRUCTION
            //
            // If XA + XB < 1:
            //
            // mantissa = 1 + XA + XB
            //
            // If XA + XB >= 1:
            //
            // normalize by increasing exponent
            // =================================

            if (frac_sum[N-1] == 1'b1) begin

                // Overflow in fractional portion
                exponent_sum = exponent_sum + 1;

                mantissa =
                    (1 << (N-1)) +
                    ((frac_sum - (1 << (N-1))) >> 1);

            end
            else begin

                mantissa =
                    (1 << (N-1)) +
                    frac_sum;

            end


            // =================================
            // ANTILOG
            //
            // mantissa represents:
            //
            // mantissa / 2^(N-1)
            //
            // Therefore:
            //
            // P =
            // mantissa *
            // 2^(exponent_sum-(N-1))
            // =================================

            if (exponent_sum >= (N-1)) begin

                shift_amount =
                    exponent_sum - (N-1);

                temp_result =
                    mantissa << shift_amount;

            end
            else begin

                shift_amount =
                    (N-1) - exponent_sum;

                temp_result =
                    mantissa >> shift_amount;

            end


            P = temp_result;

        end

    end

endmodule