`timescale 1ns / 1ps

module actual_multiplier #(
    parameter N = 8
)(
    input  wire [N-1:0] A,
    input  wire [N-1:0] B,
    output wire [(2*N)-1:0] P
);

    // Exact unsigned multiplication
    assign P = A * B;

endmodule