module adam_baseline_synth (
    input  wire [7:0] A,
    input  wire [7:0] B,
    output wire [15:0] P
);

    adam_baseline CORE (
        .A(A),
        .B(B),
        .P(P),

        .zero_debug(),
        .kA_debug(),
        .kB_debug(),
        .mantA_debug(),
        .mantB_debug(),
        .mant_sum_debug(),
        .mant_carry_debug(),
        .fault_debug()
    );

endmodule