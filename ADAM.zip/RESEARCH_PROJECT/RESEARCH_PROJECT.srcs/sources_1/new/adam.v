`timescale 1ns/1ps

// ============================================================
// BASELINE AdAM
// N = 8, T = 2, H = 3
// ============================================================

// ------------------------------------------------------------
// LEADING ONE DETECTOR
// ------------------------------------------------------------
module adam_lod #(
    parameter N = 8
)(
    input  wire [N-1:0] x,
    output reg  [$clog2(N)-1:0] k,
    output reg  zero
);

    integer i;
    reg found;

    always @(*) begin
        k = 0;
        found = 1'b0;

        for (i=N-1; i>=0; i=i-1) begin
            if ((!found) && x[i]) begin
                k = i;
                found = 1'b1;
            end
        end

        zero = ~found;
    end

endmodule


// ------------------------------------------------------------
// PFA / FULL ADDER
// ------------------------------------------------------------
module adam_pfa(
    input  wire a,
    input  wire b,
    input  wire cin,
    output wire sum,
    output wire cout
);

    assign sum  = a ^ b ^ cin;
    assign cout = (a & b) |
                  (a & cin) |
                  (b & cin);

endmodule


// ------------------------------------------------------------
// CLA STYLE ADDER
// ------------------------------------------------------------
module adam_cla #(
    parameter WIDTH = 4
)(
    input  wire [WIDTH-1:0] a,
    input  wire [WIDTH-1:0] b,
    input  wire cin,
    output wire [WIDTH-1:0] sum,
    output wire [WIDTH:0] carry
);

    wire [WIDTH-1:0] p;
    wire [WIDTH-1:0] g;

    assign p = a ^ b;
    assign g = a & b;

    assign carry[0] = cin;

    genvar gi;

    generate
        for (gi=0; gi<WIDTH; gi=gi+1) begin : GEN_CLA_BITS

            assign carry[gi+1] =
                g[gi] |
                (p[gi] & carry[gi]);

            assign sum[gi] =
                p[gi] ^ carry[gi];

        end
    endgenerate

endmodule


// ------------------------------------------------------------
// HYBRID ADDER
// Lower part = ripple
// Upper part = CLA
// ------------------------------------------------------------
module adam_hybrid #(
    parameter WIDTH = 4
)(
    input  wire [WIDTH-1:0] a,
    input  wire [WIDTH-1:0] b,
    output wire [WIDTH-1:0] sum
);

    localparam LOWER_WIDTH = WIDTH/2;
    localparam UPPER_WIDTH = WIDTH-LOWER_WIDTH;

    wire [LOWER_WIDTH:0] lower_carry;

    wire [UPPER_WIDTH-1:0] upper_sum;
    wire [UPPER_WIDTH:0] upper_carry;

    assign lower_carry[0] = 1'b0;

    genvar hi;

    generate
        for (hi=0; hi<LOWER_WIDTH; hi=hi+1)
        begin : GEN_HYBRID_RIPPLE

            adam_pfa FA(
                .a(a[hi]),
                .b(b[hi]),
                .cin(lower_carry[hi]),
                .sum(sum[hi]),
                .cout(lower_carry[hi+1])
            );

        end
    endgenerate


    adam_cla #(
        .WIDTH(UPPER_WIDTH)
    ) UPPER_CLA (
        .a(a[WIDTH-1:LOWER_WIDTH]),
        .b(b[WIDTH-1:LOWER_WIDTH]),
        .cin(lower_carry[LOWER_WIDTH]),
        .sum(upper_sum),
        .carry(upper_carry)
    );


    assign sum[WIDTH-1:LOWER_WIDTH] = upper_sum;

endmodule


// ------------------------------------------------------------
// MAJORITY VOTER
// ------------------------------------------------------------
module adam_majority(
    input  wire a,
    input  wire b,
    input  wire c,
    output wire y
);

    assign y = (a & b) |
               (a & c) |
               (b & c);

endmodule


// ------------------------------------------------------------
// TMR CHARACTERISTIC ADDER
// ------------------------------------------------------------
module adam_tmr #(
    parameter WIDTH = 4
)(
    input  wire [WIDTH-1:0] a,
    input  wire [WIDTH-1:0] b,
    output wire [WIDTH-1:0] sum
);

    wire [WIDTH-1:0] result1;
    wire [WIDTH-1:0] result2;
    wire [WIDTH-1:0] result3;

    adam_hybrid #(.WIDTH(WIDTH)) ADDER1 (
        .a(a),
        .b(b),
        .sum(result1)
    );

    adam_hybrid #(.WIDTH(WIDTH)) ADDER2 (
        .a(a),
        .b(b),
        .sum(result2)
    );

    adam_hybrid #(.WIDTH(WIDTH)) ADDER3 (
        .a(a),
        .b(b),
        .sum(result3)
    );


    genvar vi;

    generate
        for (vi=0; vi<WIDTH; vi=vi+1)
        begin : GEN_TMR_VOTERS

            adam_majority VOTER (
                .a(result1[vi]),
                .b(result2[vi]),
                .c(result3[vi]),
                .y(sum[vi])
            );

        end
    endgenerate

endmodule


// ------------------------------------------------------------
// ADAPTIVE MANTISSA ADDER
// ------------------------------------------------------------
module adam_adaptive #(
    parameter N = 8,
    parameter T = 2,
    parameter H = 3
)(
    input  wire [N-2:0] a,
    input  wire [N-2:0] b,
    input  wire [$clog2(N)-1:0] k,

    output wire [N-2:0] sum,
    output wire carry_out,
    output wire fault_detected
);

    localparam M  = N-1;
    localparam KW = $clog2(N);

    wire [KW:0] wx;
    wire [KW:0] war;
    wire [KW:0] wpb;

    // Adaptive equations
    assign wx =
        (k < (N-T)) ?
        k :
        (M-T);

    assign war = M-wx;

    assign wpb =
        (war < H) ?
        war :
        H;


    // --------------------------------------------------------
    // PRIMARY ADDER
    // --------------------------------------------------------
    wire [M-1:0] primary_sum;
    wire [M:0] primary_carry;

    adam_cla #(
        .WIDTH(M)
    ) PRIMARY_ADDER (
        .a(a),
        .b(b),
        .cin(1'b0),
        .sum(primary_sum),
        .carry(primary_carry)
    );


    // --------------------------------------------------------
    // REDUNDANT UPPER H BITS
    // --------------------------------------------------------
    wire [H-1:0] red_a;
    wire [H-1:0] red_b;

    assign red_a = a[M-1 -: H];
    assign red_b = b[M-1 -: H];

    wire [H-1:0] duplicate_sum;
    wire [H:0] duplicate_carry;

    // Carry entering redundant section
    assign duplicate_carry[0] =
        primary_carry[M-H];


    genvar di;

    generate
        for (di=0; di<H; di=di+1)
        begin : GEN_DUPLICATE_BITS

            wire p_bit;
            wire g_bit;

            assign p_bit =
                red_a[di] ^ red_b[di];

            assign g_bit =
                red_a[di] & red_b[di];

            assign duplicate_sum[di] =
                p_bit ^ duplicate_carry[di];

            assign duplicate_carry[di+1] =
                g_bit |
                (p_bit & duplicate_carry[di]);

        end
    endgenerate


    // --------------------------------------------------------
    // ALIGN DUPLICATE RESULT
    // --------------------------------------------------------
    wire [M-1:0] duplicate_full;
    wire [M-1:0] protected_mask;


    genvar mi;

    generate
        for (mi=0; mi<M; mi=mi+1)
        begin : GEN_PROTECTION_MASK

            if (mi >= (M-H))
            begin : GEN_PROTECTED_POSITION

                localparam integer DUP_INDEX =
                    mi-(M-H);

                assign duplicate_full[mi] =
                    duplicate_sum[DUP_INDEX];

                assign protected_mask[mi] =
                    ((H-1-DUP_INDEX) < wpb);

            end
            else
            begin : GEN_NORMAL_POSITION

                assign duplicate_full[mi] =
                    1'b0;

                assign protected_mask[mi] =
                    1'b0;

            end

        end
    endgenerate


    // --------------------------------------------------------
    // FAULT DETECTION
    // --------------------------------------------------------
    assign fault_detected =
        |((primary_sum ^ duplicate_full)
          & protected_mask);


    // --------------------------------------------------------
    // ERROR MASKING
    // --------------------------------------------------------
    assign sum =
        (primary_sum & ~protected_mask) |
        ((primary_sum & duplicate_full)
         & protected_mask);


    assign carry_out =
        primary_carry[M];

endmodule


// ------------------------------------------------------------
// RECONSTRUCTION
//
// Fractional adder output represents XA + XB.
//
// If carry = 0:
//      1 + XA + XB = 1.xxxxx
//
// If carry = 1:
//      XA + XB = 1.xxxxx
//
// Therefore:
//      1 + XA + XB = 10.xxxxx
//
// We reconstruct directly as a fixed-point integer.
// ------------------------------------------------------------
module adam_reconstruct #(
    parameter N = 8
)(
    input  wire [$clog2(N):0] exponent,
    input  wire [N-2:0] fraction,
    input  wire fraction_carry,

    output reg [2*N-1:0] product
);

    localparam M = N-1;

    // M fractional bits + integer field.
    reg [M+1:0] significand;

    reg [2*N-1:0] temp;

    integer exp_int;
    integer shift_amount;

    always @(*) begin

        // ---------------------------------------------
        // 1 + XA + XB
        // ---------------------------------------------
        if (fraction_carry) begin

            // 10.xxxxx
            significand =
                {2'b10, fraction};

        end
        else begin

            // 01.xxxxx
            significand =
                {2'b01, fraction};

        end


        exp_int = exponent;

        temp = 0;


        // significand has M fractional bits.
        //
        // product =
        // significand * 2^exponent / 2^M

        if (exp_int >= M) begin

            shift_amount =
                exp_int-M;

            temp =
                significand << shift_amount;

        end
        else begin

            shift_amount =
                M-exp_int;

            temp =
                significand >> shift_amount;

        end


        product = temp;

    end

endmodule


// ============================================================
// BASELINE TOP MODULE
// ============================================================
module adam_baseline #(
    parameter N = 8,
    parameter T = 2,
    parameter H = 3
)(
    input  wire [N-1:0] A,
    input  wire [N-1:0] B,

    output wire [2*N-1:0] P,

    output wire zero_debug,

    output wire [$clog2(N)-1:0] kA_debug,
    output wire [$clog2(N)-1:0] kB_debug,

    output wire [N-2:0] mantA_debug,
    output wire [N-2:0] mantB_debug,

    output wire [N-2:0] mant_sum_debug,

    output wire mant_carry_debug,
    output wire fault_debug
);

    localparam M  = N-1;
    localparam KW = $clog2(N);


    // --------------------------------------------------------
    // LOD
    // --------------------------------------------------------
    wire [KW-1:0] kA;
    wire [KW-1:0] kB;

    wire zeroA;
    wire zeroB;

    adam_lod #(.N(N)) LOD_A (
        .x(A),
        .k(kA),
        .zero(zeroA)
    );

    adam_lod #(.N(N)) LOD_B (
        .x(B),
        .k(kB),
        .zero(zeroB)
    );


    wire zero_flag;

    assign zero_flag =
        zeroA | zeroB;


    // --------------------------------------------------------
    // NORMALIZATION
    // --------------------------------------------------------
    wire [KW-1:0] shiftA;
    wire [KW-1:0] shiftB;

    assign shiftA = M-kA;
    assign shiftB = M-kB;


    wire [N-1:0] normA;
    wire [N-1:0] normB;

    assign normA =
        A << shiftA;

    assign normB =
        B << shiftB;


    wire [M-1:0] mantA_raw;
    wire [M-1:0] mantB_raw;

    assign mantA_raw =
        normA[M-1:0];

    assign mantB_raw =
        normB[M-1:0];


    // --------------------------------------------------------
    // ADAPTIVE TRUNCATION
    // --------------------------------------------------------
    reg [M-1:0] mantA;
    reg [M-1:0] mantB;

    integer keepA;
    integer keepB;

    integer discardA;
    integer discardB;

    integer ti;

    always @(*) begin

        // Operand A
        if (kA < (N-T))
            keepA = kA;
        else
            keepA = M-T;

        discardA = M-keepA;

        mantA = {M{1'b0}};

        for (ti=0; ti<M; ti=ti+1) begin
            if (ti >= discardA)
                mantA[ti] = mantA_raw[ti];
        end


        // Operand B
        if (kB < (N-T))
            keepB = kB;
        else
            keepB = M-T;

        discardB = M-keepB;

        mantB = {M{1'b0}};

        for (ti=0; ti<M; ti=ti+1) begin
            if (ti >= discardB)
                mantB[ti] = mantB_raw[ti];
        end

    end


    // --------------------------------------------------------
    // MAXIMUM CHARACTERISTIC
    // --------------------------------------------------------
    wire [KW-1:0] kmax;

    assign kmax =
        (kA > kB) ?
        kA :
        kB;


    // --------------------------------------------------------
    // ADAPTIVE ADDER
    // --------------------------------------------------------
    wire [M-1:0] mant_sum;
    wire mant_carry;

    wire fault_detected;

    adam_adaptive #(
        .N(N),
        .T(T),
        .H(H)
    ) ADAPTIVE (
        .a(mantA),
        .b(mantB),
        .k(kmax),

        .sum(mant_sum),
        .carry_out(mant_carry),

        .fault_detected(fault_detected)
    );


    // --------------------------------------------------------
    // TMR CHARACTERISTIC ADDER
    // --------------------------------------------------------
    wire [KW:0] ksum;

    adam_tmr #(
        .WIDTH(KW+1)
    ) TMR (
        .a({1'b0,kA}),
        .b({1'b0,kB}),
        .sum(ksum)
    );


    // --------------------------------------------------------
    // RECONSTRUCTION
    // --------------------------------------------------------
    wire [2*N-1:0] reconstructed;

    adam_reconstruct #(
        .N(N)
    ) RECONSTRUCT (
        .exponent(ksum),
        .fraction(mant_sum),
        .fraction_carry(mant_carry),
        .product(reconstructed)
    );


    // --------------------------------------------------------
    // FINAL ZERO HANDLING
    // --------------------------------------------------------
    assign P =
        zero_flag ?
        {2*N{1'b0}} :
        reconstructed;


    // Debug
    assign zero_debug =
        zero_flag;

    assign kA_debug =
        kA;

    assign kB_debug =
        kB;

    assign mantA_debug =
        mantA;

    assign mantB_debug =
        mantB;

    assign mant_sum_debug =
        mant_sum;

    assign mant_carry_debug =
        mant_carry;

    assign fault_debug =
        fault_detected;

endmodule