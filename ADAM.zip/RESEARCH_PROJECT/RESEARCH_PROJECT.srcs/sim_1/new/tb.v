`timescale 1ns/1ps

module tb_adam_compare;

    // ============================================================
    // INPUTS
    // ============================================================

    reg [7:0] A;
    reg [7:0] B;


    // ============================================================
    // BASELINE OUTPUT
    // ============================================================

    wire [15:0] P_base;

    wire zero_base;

    wire [2:0] kA_base;
    wire [2:0] kB_base;

    wire [6:0] mantA_base;
    wire [6:0] mantB_base;

    wire [6:0] mant_sum_base;

    wire carry_base;
    wire fault_base;


    // ============================================================
    // MODIFIED OUTPUT
    // ============================================================

    wire [15:0] P_mod;

    wire zero_mod;

    wire [2:0] kA_mod;
    wire [2:0] kB_mod;

    wire [6:0] mantA_mod;
    wire [6:0] mantB_mod;

    wire [6:0] mant_sum_mod;

    wire carry_mod;
    wire fault_mod;

    wire [2:0] duplicate_enable;
    wire [2:0] isolated_a;
    wire [2:0] isolated_b;


    // ============================================================
    // BASELINE DUT
    // ============================================================

    adam_baseline #(
        .N(8),
        .T(2),
        .H(3)
    ) DUT_BASE (

        .A(A),
        .B(B),

        .P(P_base),

        .zero_debug(zero_base),

        .kA_debug(kA_base),
        .kB_debug(kB_base),

        .mantA_debug(mantA_base),
        .mantB_debug(mantB_base),

        .mant_sum_debug(mant_sum_base),

        .mant_carry_debug(carry_base),

        .fault_debug(fault_base)
    );


    // ============================================================
    // MODIFIED DUT
    // ============================================================

    adam_modified #(
        .N(8),
        .T(2),
        .H(3)
    ) DUT_MOD (

        .A(A),
        .B(B),

        .P(P_mod),

        .zero_debug(zero_mod),

        .kA_debug(kA_mod),
        .kB_debug(kB_mod),

        .mantA_debug(mantA_mod),
        .mantB_debug(mantB_mod),

        .mant_sum_debug(mant_sum_mod),

        .mant_carry_debug(carry_mod),

        .duplicate_enable_debug(
            duplicate_enable
        ),

        .isolated_a_debug(
            isolated_a
        ),

        .isolated_b_debug(
            isolated_b
        ),

        .fault_debug(fault_mod)
    );


    // ============================================================
    // TEST VARIABLES
    // ============================================================

    integer i;
    integer j;

    integer exact_value;
    integer base_value;
    integer mod_value;

    integer abs_error;
    integer mod_abs_error;

    integer mismatch_count;

    integer exact_count;
    integer nonzero_error_count;

    integer zero_test_count;
    integer zero_fail_count;

    integer max_error;
    integer max_error_a;
    integer max_error_b;
    integer max_error_exact;
    integer max_error_approx;

    real relative_error;
    real max_relative_error;

    integer max_relative_a;
    integer max_relative_b;

    real total_abs_error;
    real total_squared_error;
    real total_relative_error;

    real MAE;
    real MSE;
    real RMSE;
    real MRE;

    real accuracy_percent;


    // ============================================================
    // ERROR HISTOGRAM
    //
    // 0      = exact
    // 1-9    = small error
    // 10-49
    // 50-99
    // 100-499
    // 500-999
    // 1000-4999
    // 5000-9999
    // >=10000
    // ============================================================

    integer hist_0;
    integer hist_1_9;
    integer hist_10_49;
    integer hist_50_99;
    integer hist_100_499;
    integer hist_500_999;
    integer hist_1000_4999;
    integer hist_5000_9999;
    integer hist_10000_plus;


    // ============================================================
    // TOP 10 ERROR ARRAYS
    // ============================================================

    integer top_error [0:9];
    integer top_a     [0:9];
    integer top_b     [0:9];
    integer top_exact [0:9];
    integer top_approx[0:9];

    integer pos;
    integer q;


    // ============================================================
    // MAIN TEST
    // ============================================================

    initial begin

        // --------------------------------------------------------
        // Initialize statistics
        // --------------------------------------------------------

        mismatch_count = 0;

        exact_count = 0;

        nonzero_error_count = 0;

        zero_test_count = 0;

        zero_fail_count = 0;

        max_error = 0;

        max_error_a = 0;
        max_error_b = 0;

        max_error_exact = 0;
        max_error_approx = 0;

        max_relative_error = 0.0;

        max_relative_a = 0;
        max_relative_b = 0;

        total_abs_error = 0.0;

        total_squared_error = 0.0;

        total_relative_error = 0.0;


        // --------------------------------------------------------
        // Initialize histogram
        // --------------------------------------------------------

        hist_0 = 0;
        hist_1_9 = 0;
        hist_10_49 = 0;
        hist_50_99 = 0;
        hist_100_499 = 0;
        hist_500_999 = 0;
        hist_1000_4999 = 0;
        hist_5000_9999 = 0;
        hist_10000_plus = 0;


        // --------------------------------------------------------
        // Initialize top-10 arrays
        // --------------------------------------------------------

        for (q=0; q<10; q=q+1) begin

            top_error[q] = -1;
            top_a[q] = 0;
            top_b[q] = 0;
            top_exact[q] = 0;
            top_approx[q] = 0;

        end


        // --------------------------------------------------------
        // Header
        // --------------------------------------------------------

        $display("");
        $display("============================================================");
        $display("        EXHAUSTIVE AdAM ERROR ANALYSIS");
        $display("============================================================");
        $display("Operand Width       = 8 bits");
        $display("Truncation T        = 2");
        $display("Protection H        = 3");
        $display("Total Input Pairs   = 65536");
        $display("============================================================");
        $display("");


        // ========================================================
        // EXHAUSTIVE 256 x 256 TEST
        // ========================================================

        for (i=0; i<256; i=i+1) begin

            for (j=0; j<256; j=j+1) begin

                // ------------------------------------------------
                // Apply input
                // ------------------------------------------------

                A = i;
                B = j;

                #1;


                // ------------------------------------------------
                // Exact multiplication
                // ------------------------------------------------

                exact_value =
                    i * j;


                // ------------------------------------------------
                // Read outputs
                // ------------------------------------------------

                base_value =
                    P_base;

                mod_value =
                    P_mod;


                // =================================================
                // BASELINE VS MODIFIED FUNCTIONAL EQUIVALENCE
                // =================================================

                if (base_value != mod_value) begin

                    mismatch_count =
                        mismatch_count + 1;


                    // Print only first 20 mismatches
                    if (mismatch_count <= 20) begin

                        $display(
                            "MISMATCH: A=%0d B=%0d BASE=%0d MOD=%0d",
                            i,
                            j,
                            base_value,
                            mod_value
                        );

                    end

                end


                // =================================================
                // ABSOLUTE ERROR
                // =================================================

                if (exact_value >= base_value) begin

                    abs_error =
                        exact_value - base_value;

                end
                else begin

                    abs_error =
                        base_value - exact_value;

                end


                // ------------------------------------------------
                // Statistics
                // ------------------------------------------------

                total_abs_error =
                    total_abs_error +
                    abs_error;


                total_squared_error =
                    total_squared_error +
                    (abs_error * abs_error);


                // =================================================
                // EXACT / NON-EXACT
                // =================================================

                if (abs_error == 0) begin

                    exact_count =
                        exact_count + 1;

                end
                else begin

                    nonzero_error_count =
                        nonzero_error_count + 1;

                end


                // =================================================
                // ERROR HISTOGRAM
                // =================================================

                if (abs_error == 0) begin

                    hist_0 =
                        hist_0 + 1;

                end
                else if (abs_error <= 9) begin

                    hist_1_9 =
                        hist_1_9 + 1;

                end
                else if (abs_error <= 49) begin

                    hist_10_49 =
                        hist_10_49 + 1;

                end
                else if (abs_error <= 99) begin

                    hist_50_99 =
                        hist_50_99 + 1;

                end
                else if (abs_error <= 499) begin

                    hist_100_499 =
                        hist_100_499 + 1;

                end
                else if (abs_error <= 999) begin

                    hist_500_999 =
                        hist_500_999 + 1;

                end
                else if (abs_error <= 4999) begin

                    hist_1000_4999 =
                        hist_1000_4999 + 1;

                end
                else if (abs_error <= 9999) begin

                    hist_5000_9999 =
                        hist_5000_9999 + 1;

                end
                else begin

                    hist_10000_plus =
                        hist_10000_plus + 1;

                end


                // =================================================
                // MAXIMUM ABSOLUTE ERROR
                // =================================================

                if (abs_error > max_error) begin

                    max_error =
                        abs_error;

                    max_error_a =
                        i;

                    max_error_b =
                        j;

                    max_error_exact =
                        exact_value;

                    max_error_approx =
                        base_value;

                end


                // =================================================
                // RELATIVE ERROR
                //
                // Do not divide by zero.
                // =================================================

                if (exact_value != 0) begin

                    relative_error =
                        (
                            abs_error * 100.0
                        ) /
                        exact_value;


                    total_relative_error =
                        total_relative_error +
                        relative_error;


                    if (relative_error >
                        max_relative_error) begin

                        max_relative_error =
                            relative_error;

                        max_relative_a =
                            i;

                        max_relative_b =
                            j;

                    end

                end


                // =================================================
                // ZERO INPUT VERIFICATION
                // =================================================

                if ((i == 0) || (j == 0)) begin

                    zero_test_count =
                        zero_test_count + 1;


                    if (base_value != 0) begin

                        zero_fail_count =
                            zero_fail_count + 1;

                    end


                    if (mod_value != 0) begin

                        zero_fail_count =
                            zero_fail_count + 1;

                    end

                end


                // =================================================
                // TOP 10 ERROR CASES
                // =================================================

                for (pos=0; pos<10; pos=pos+1) begin

                    if (
                        (abs_error > top_error[pos])
                    ) begin

                        // Shift lower entries down
                        for (
                            q=9;
                            q>pos;
                            q=q-1
                        ) begin

                            top_error[q] =
                                top_error[q-1];

                            top_a[q] =
                                top_a[q-1];

                            top_b[q] =
                                top_b[q-1];

                            top_exact[q] =
                                top_exact[q-1];

                            top_approx[q] =
                                top_approx[q-1];

                        end


                        // Insert new entry
                        top_error[pos] =
                            abs_error;

                        top_a[pos] =
                            i;

                        top_b[pos] =
                            j;

                        top_exact[pos] =
                            exact_value;

                        top_approx[pos] =
                            base_value;

                        // Stop checking this input
                        pos = 10;

                    end

                end

            end

        end


        // ========================================================
        // FINAL METRICS
        // ========================================================

        MAE =
            total_abs_error /
            65536.0;


        MSE =
            total_squared_error /
            65536.0;


        RMSE =
            $sqrt(MSE);


        // There are 65,536 combinations, but 511 have exact=0:
        // A=0 OR B=0
        //
        // Therefore use non-zero exact products for MRE.
        MRE =
            total_relative_error /
            (65536.0 - 511.0);


        accuracy_percent =
            (exact_count * 100.0) /
            65536.0;


        // ========================================================
        // FINAL REPORT
        // ========================================================

        $display("");
        $display("");
        $display("============================================================");
        $display("                 FINAL ERROR REPORT");
        $display("============================================================");

        $display("");
        $display("INPUT SPACE");
        $display("------------------------------------------------------------");
        $display("Total combinations        = %0d", 65536);
        $display("Tested combinations       = %0d",
                 65536);


        $display("");
        $display("FUNCTIONAL EQUIVALENCE");
        $display("------------------------------------------------------------");

        $display(
            "Baseline/Modified mismatches = %0d",
            mismatch_count
        );


        if (mismatch_count == 0) begin

            $display(
                "Functional equivalence       = PASS"
            );

        end
        else begin

            $display(
                "Functional equivalence       = FAIL"
            );

        end


        $display("");
        $display("APPROXIMATION ERROR");
        $display("------------------------------------------------------------");

        $display(
            "Exact results             = %0d",
            exact_count
        );

        $display(
            "Non-zero error results    = %0d",
            nonzero_error_count
        );

        $display(
            "Exact result percentage   = %f %%",
            accuracy_percent
        );

        $display(
            "MAE                       = %f",
            MAE
        );

        $display(
            "MSE                       = %f",
            MSE
        );

        $display(
            "RMSE                      = %f",
            RMSE
        );

        $display(
            "Mean Relative Error       = %f %%",
            MRE
        );


        $display("");
        $display("MAXIMUM ABSOLUTE ERROR");
        $display("------------------------------------------------------------");

        $display(
            "Maximum absolute error    = %0d",
            max_error
        );

        $display(
            "Input A                   = %0d",
            max_error_a
        );

        $display(
            "Input B                   = %0d",
            max_error_b
        );

        $display(
            "Exact product             = %0d",
            max_error_exact
        );

        $display(
            "AdAM output               = %0d",
            max_error_approx
        );


        $display("");
        $display("MAXIMUM RELATIVE ERROR");
        $display("------------------------------------------------------------");

        $display(
            "Maximum relative error    = %f %%",
            max_relative_error
        );

        $display(
            "Input A                   = %0d",
            max_relative_a
        );

        $display(
            "Input B                   = %0d",
            max_relative_b
        );


        $display("");
        $display("ZERO INPUT VERIFICATION");
        $display("------------------------------------------------------------");

        $display(
            "Zero-input test cases     = %0d",
            zero_test_count
        );

        $display(
            "Zero-output failures      = %0d",
            zero_fail_count
        );


        if (zero_fail_count == 0) begin

            $display(
                "Zero handling             = PASS"
            );

        end
        else begin

            $display(
                "Zero handling             = FAIL"
            );

        end


        // ========================================================
        // HISTOGRAM
        // ========================================================

        $display("");
        $display("ERROR HISTOGRAM");
        $display("------------------------------------------------------------");

        $display(
            "Error = 0             : %0d",
            hist_0
        );

        $display(
            "Error = 1-9           : %0d",
            hist_1_9
        );

        $display(
            "Error = 10-49         : %0d",
            hist_10_49
        );

        $display(
            "Error = 50-99         : %0d",
            hist_50_99
        );

        $display(
            "Error = 100-499       : %0d",
            hist_100_499
        );

        $display(
            "Error = 500-999       : %0d",
            hist_500_999
        );

        $display(
            "Error = 1000-4999     : %0d",
            hist_1000_4999
        );

        $display(
            "Error = 5000-9999     : %0d",
            hist_5000_9999
        );

        $display(
            "Error >= 10000        : %0d",
            hist_10000_plus
        );


        // ========================================================
        // TOP 10
        // ========================================================

        $display("");
        $display("TOP 10 MAXIMUM ERROR CASES");
        $display("------------------------------------------------------------");

        for (q=0; q<10; q=q+1) begin

            $display(
                "%0d. A=%0d B=%0d Exact=%0d AdAM=%0d Error=%0d",
                q+1,
                top_a[q],
                top_b[q],
                top_exact[q],
                top_approx[q],
                top_error[q]
            );

        end


        // ========================================================
        // SUMMARY
        // ========================================================

        $display("");
        $display("============================================================");
        $display("                       SUMMARY");
        $display("============================================================");

        if (mismatch_count == 0) begin

            $display(
                "PASS: Baseline and Modified AdAM are functionally"
            );

            $display(
                "      identical for all 65,536 input combinations."
            );

        end
        else begin

            $display(
                "FAIL: Baseline and Modified AdAM differ."
            );

        end


        if (zero_fail_count == 0) begin

            $display(
                "PASS: Zero-input handling verified."
            );

        end
        else begin

            $display(
                "FAIL: Zero-input handling error detected."
            );

        end


        $display("");
        $display(
            "MAE  = %f",
            MAE
        );

        $display(
            "RMSE = %f",
            RMSE
        );

        $display(
            "Max Error = %0d",
            max_error
        );


        $display("");
        $display("============================================================");
        $display("                 EXHAUSTIVE TEST COMPLETE");
        $display("============================================================");
        $display("");


        #10;

        $finish;

    end

endmodule