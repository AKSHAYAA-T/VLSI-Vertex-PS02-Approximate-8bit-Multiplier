`timescale 1ns/1ps
//============================================================
// Exhaustive testbench: every (a,b) pair from 0..2^N-1
// For N=8 -> 65,536 test cases (00000000 .. 11111111 each)
//============================================================
module tb_log_multiplier;
    parameter N = 8;
    parameter K = 3;                    // K = log2(N)

    reg  [N-1:0]   a, b;
    wire [2*N-1:0] p;

    log_multiplier #(N,K) dut (.a(a), .b(b), .p(p));

    integer i, j;
    integer exact, approx, err, abs_err;
    integer total, nonzero, exact_hits;
    integer max_abs_err, max_a, max_b;
    real    rel_err, sum_rel, max_rel;
    integer fd;

    initial begin
        total = 0; nonzero = 0; exact_hits = 0;
        max_abs_err = 0; max_a = 0; max_b = 0;
        sum_rel = 0.0; max_rel = 0.0;

        fd = $fopen("log_mult_results.txt", "w");
        $fdisplay(fd, "     A        B     |  A_dec B_dec | Exact  Approx | Error  Rel_Err(%%)");

        for (i = 0; i < (1<<N); i = i + 1) begin
            for (j = 0; j < (1<<N); j = j + 1) begin
                a = i; b = j;
                #1;                                  // let combinational logic settle

                exact  = i * j;
                approx = p;
                err    = exact - approx;             // Mitchell always underestimates
                abs_err = (err < 0) ? -err : err;
                total  = total + 1;

                if (exact != 0) begin
                    rel_err = (abs_err * 100.0) / exact;
                    sum_rel = sum_rel + rel_err;
                    nonzero = nonzero + 1;
                    if (rel_err > max_rel) max_rel = rel_err;
                end else
                    rel_err = 0.0;

                if (err == 0) exact_hits = exact_hits + 1;
                if (abs_err > max_abs_err) begin
                    max_abs_err = abs_err; max_a = i; max_b = j;
                end

                // sanity: zero operand must give zero
                if ((i == 0 || j == 0) && p !== 0)
                    $display("ERROR: zero operand gave non-zero output a=%0d b=%0d p=%0d", i, j, p);

                $fdisplay(fd, "%b %b | %5d %5d | %5d %5d | %5d  %7.3f",
                          a, b, i, j, exact, approx, err, rel_err);

                // print first few & a sample to console
                if (total <= 20 || (i % 51 == 0 && j % 51 == 0))
                    $display("a=%b (%3d)  b=%b (%3d)  exact=%5d  approx=%5d  err=%5d  rel=%6.2f%%",
                             a, i, b, j, exact, approx, err, rel_err);
            end
        end

        $display("\n================ SUMMARY (N=%0d) ================", N);
        $display("Total test cases      : %0d", total);
        $display("Exact results         : %0d", exact_hits);
        $display("Max absolute error    : %0d  (a=%0d, b=%0d)", max_abs_err, max_a, max_b);
        $display("Max relative error    : %f %%", max_rel);
        $display("Mean relative error   : %f %%", sum_rel / nonzero);
        $display("Full results written to log_mult_results.txt");
        $fclose(fd);
        $finish;
    end
endmodule