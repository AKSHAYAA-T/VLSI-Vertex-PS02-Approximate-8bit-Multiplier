`timescale 1ns/1ps
//============================================================
// Leading One Detector (LOD)
// Outputs the bit position (k) of the most significant '1'.
// valid = 0 when input is all zeros.
//============================================================
module lod #(parameter N = 8, parameter K = 3)(
    input  [N-1:0] in,
    output reg [K-1:0] pos,
    output reg         valid
);
    integer i;
    always @(*) begin
        pos   = {K{1'b0}};
        valid = 1'b0;
        for (i = 0; i < N; i = i + 1)
            if (in[i]) begin          // last (highest) '1' wins
                pos   = i[K-1:0];
                valid = 1'b1;
            end
    end
endmodule

//============================================================
// Leading Zero Detector (LZD)
// Counts the zeros above the most significant '1'.
// For input 0 use the all_zero flag (count is not meaningful).
//============================================================
module lzd #(parameter N = 8, parameter K = 3)(
    input  [N-1:0] in,
    output reg [K-1:0] count,
    output reg         all_zero
);
    integer i;
    reg found;
    always @(*) begin
        count    = {K{1'b0}};
        found    = 1'b0;
        all_zero = 1'b0;
        for (i = N-1; i >= 0; i = i - 1) begin
            if (!found) begin
                if (in[i]) found = 1'b1;
                else       count = count + 1'b1;
            end
        end
        all_zero = ~found;
    end
endmodule

//============================================================
// Mitchell logarithmic multiplier (N x N -> 2N bits)
//
//  1. LOD  -> k  = position of leading one      (characteristic)
//  2. LZD  -> lz = leading zeros = N-1-k        (used as shift amount)
//  3. Normalise: shift left by lz, drop the leading one
//                -> fraction x (N-1 bits)       (mantissa)
//  4. log2(A) ~ {k, x}     (Mitchell approximation)
//  5. Add the two logs
//  6. Antilog: result = (1.frac) * 2^characteristic
//===========================================================
module log_multiplier #(parameter N = 8, parameter K = 3)(
    input  [N-1:0]   a,
    input  [N-1:0]   b,
    output [2*N-1:0] p
);
    localparam F = N - 1;               // fraction width

    // ---------- operand A ----------
    wire [K-1:0] ka, lza;
    wire         va, za;
    lod #(N,K) lod_a (.in(a), .pos(ka),  .valid(va));
    lzd #(N,K) lzd_a (.in(a), .count(lza), .all_zero(za));

    // ---------- operand B ----------
    wire [K-1:0] kb, lzb;
    wire         vb, zb;
    lod #(N,K) lod_b (.in(b), .pos(kb),  .valid(vb));
    lzd #(N,K) lzd_b (.in(b), .count(lzb), .all_zero(zb));

    // ---------- normalise (barrel shift by LZD count) ----------
    wire [N-1:0] na = a << lza;         // MSB is the leading one
    wire [N-1:0] nb = b << lzb;
    wire [F-1:0] xa = na[F-1:0];        // fraction = bits below leading one
    wire [F-1:0] xb = nb[F-1:0];

    // ---------- log domain addition ----------
    wire [K+F-1:0] la = {ka, xa};       // log2(A) ~ k.x
    wire [K+F-1:0] lb = {kb, xb};
    wire [K+F:0]   ls = la + lb;        // 1 extra bit for carry

    wire [K:0]     ch   = ls[K+F : F];  // characteristic (carry included)
    wire [F-1:0]   frac = ls[F-1:0];

    // ---------- antilog ----------
    // value = {1,frac} * 2^ch / 2^F
    localparam W = 3*N;                 // wide enough for max shift
    wire [W-1:0] mant  = {{(W-N){1'b0}}, 1'b1, frac};
    wire [W-1:0] shift = mant << ch;
    wire [W-1:0] res   = shift >> F;

    // zero operand -> zero result
    assign p = (za | zb) ? {2*N{1'b0}} : res[2*N-1:0];
endmodule